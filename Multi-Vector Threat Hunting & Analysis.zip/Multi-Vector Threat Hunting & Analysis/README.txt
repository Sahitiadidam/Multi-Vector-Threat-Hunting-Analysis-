# Multi-Vector Threat Hunting & Analysis

## 📌 Project Overview

This project focuses on analyzing an enterprise production server under multiple simultaneous cyber attacks using **Splunk**.

As a SOC Analyst, the goal was to separate normal business traffic from suspicious activity, identify different attack vectors, find attacker IPs and targeted internal assets, and visualize the findings using a centralized security dashboard.

## 🎯 Objectives

- Analyze security logs using Splunk
- Filter normal and malicious traffic
- Identify multiple attack types
- Find attacker/source IP addresses
- Identify targeted/victim IP addresses
- Analyze attack timelines and activity patterns
- Correlate security events
- Create a multi-panel security dashboard

## 🔐 Attacks Analyzed

- DoS Attack
- DDoS Attack
- SQL Injection
- Man-in-the-Middle (MITM)
- Brute Force Attack


## 🛠️ Tools & Technologies

- **Splunk Enterprise**
- **SPL (Search Processing Language)**
- Security / Network Logs
- SOC Threat Hunting Techniques

## 🔎 Key SPL Commands Used

```text
table
stats
top
sort
where
timechart